1. Extract files from Archive.zip folder
2. Open a console/terminal inside folder with extracted files
3. Run command `node main.js`

In the terminal you will see the total number of orbits from the space map represented in map_data.txt
Please replace the data inside map_data.txt to see the total number of orbits from another map.
